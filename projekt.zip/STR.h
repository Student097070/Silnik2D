#pragma once
// Struktura przechowuj�ca informacje o rozdzielczo�ci okna i obszaru roboczego
struct Resolution {
    int w, h;                           // Szeroko�� i wysoko�� okna
    int workspace_w, workspace_h;       // Szeroko�� i wysoko�� obszaru roboczego
};

struct CircleData {
    int x, y, r;
    ALLEGRO_COLOR color;
};

struct TriangleData {
	float x0, y0, x1, y1, x2, y2;
    ALLEGRO_COLOR color;
};

struct RectangleData {
	float x0, y0, x1, y1;
	ALLEGRO_COLOR color;
};

struct Circle2Data {
	float x0, y0, R;
	ALLEGRO_COLOR color;
};

struct ElipseData {
	float x0, y0, Rx, Ry;
	ALLEGRO_COLOR color;
};

struct PolygonPoint {
	float x, y;
};

struct PolygonData {
	vector<PolygonPoint>& points;
	ALLEGRO_COLOR color;
};

struct FillPoint {
	float x, y;
};