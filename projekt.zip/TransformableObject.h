#pragma once
#include "GameObject.h"
#include "Point2D.h"

// interfejs dla obiekt�w poddawanych transformacjom
class TransformableObject : public virtual GameObject {
public:
    virtual ~TransformableObject() = default;

    // translacja
    virtual void translate(float tx, float ty) = 0;

    // obr�t o k�t alfa (radiany) wzgl�dem punktu (cx,cy)
    virtual void rotate(float alpha, float cx = 0.0f, float cy = 0.0f) = 0;

    // skalowanie wzgl�dem punktu (cx,cy), kx,ky - wsp�czynniki
    virtual void scale(float kx, float ky, float cx = 0.0f, float cy = 0.0f) = 0;
};
