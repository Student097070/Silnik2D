#pragma once

// Najwy�sza klasa bazowa (abstrakcyjna)
class GameObject {
public:
    virtual ~GameObject() = default;
};
